function [w, e, Pxy] = main_scca(IM3D, y, width, sk)

[Its Pxy] = extract_Its(IM3D, width);
X = Its(:,1:length(y));
Y = make_Y(y, X);

Kb = time_gramm2(Y', 10);
%Kb = Y'*Y;
figure;plot(X')
figure;plot(Kb)
pause(Inf)
[w, e, correlation, optval, beta] = scca_cvx_singleprog_tau(X, Kb, 1, sk);
%viz_w(w, Pxy, IM3D(:,:,1))
Pxy_selected = select_w(w, Pxy, 0.001);
IM = IM3D(:,:,50);
whos Pxy_selected
convexhull_seg(Pxy_selected, IM');