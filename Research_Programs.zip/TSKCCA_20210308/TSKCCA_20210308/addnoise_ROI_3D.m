function ROI_3D2 = addnoise_ROI_3D(ROI_3D, sig)

[mrow mcol T] = size(ROI_3D);
ROI_3D2 = ROI_3D;

for t = 1:T
  ROI_3D2(:,:,t) = ROI_3D(:,:,t) + sig*randn(mrow, mcol);
end