function viz_mark(IM,  w, Pxy, width, N)

figure
imagesc(IM)
hold on
count = 1

for i=1:sqrt(N)
	for j = 1:sqrt(N)
		mks = 2e4*abs(w(count));
		%plot(1 + (i-1)*width, 1 + (j-1)*width,  'm.', 'markersize', mks)
		plot(1 + (i-1)*width, 1 + (j-1)*width,  'm.', 'markersize', 30)
		count = count + 1;
	end
end

colormap gray
axis equal
set(gcf,'color','k')
Pxy2 = Pxy(abs(w) > 1e-4, :)
convexhull_seg(Pxy2, IM);