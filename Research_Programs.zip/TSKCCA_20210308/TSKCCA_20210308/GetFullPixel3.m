function Pixel = GetFullPixel3(num)
%UNTITLED3 この関数の概要をここに記述
%   詳細説明をここに記述
%画像にある代表点座標の輝度値を抽出するプログラム。座標は等間隔に900点。実行時間は30分ほど。

Y = cell(1,num);
Interval = 22500/num;
Interval = sqrt(Interval);
X = [];
numfiles = 1200;
mydata = cell(21, numfiles);
n = 1;
for i = 1:Interval:150
  for j = 1:Interval:150
        for k = 21:numfiles
        myfilename = sprintf('%d.jpeg', k);
        I = imread(myfilename);
        pixel = impixel(I,i,j);
        Y{n} = [Y{n} ; pixel];
        end
    n = n + 1;
    
    end
end

num3 = num * 3;
 
Y = cell2mat(Y) %cell配列をdouble型配列へ変換
Y = Y(:,1:3:num3); %ピクセルがnum×3になっているので、num×1になおす
Pixel = Y;

 for k = 21:numfiles
 X = [X ; k];
 end

hold on
for  m = 1:1:num
plot(X,Y(:,m))
end
xlabel('フレーム')
ylabel('輝度値')
title('1180枚の代表点の輝度値抽出')
hold off


end

