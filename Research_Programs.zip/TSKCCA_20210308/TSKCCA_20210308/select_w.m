function Pxy2 = select_w(w, Pxy, thresh)


w = w/sum(w);
disp(sprintf('Max w: %g', max(w)))
count = 1;

for i=1:length(w)
	if abs(w(i)) > thresh
		Pxy2(count, :) = Pxy(i, :);
		count = count + 1;
	end
end



