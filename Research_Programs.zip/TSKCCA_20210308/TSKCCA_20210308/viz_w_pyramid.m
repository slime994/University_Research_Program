function HM = viz_w_pyramid(w, Pxy, IM2D, scale)


w = w/sum(w);


count =  1;
N = sqrt(length(Pxy));
for id_row = 1:N
	for id_col = 1:N
		if abs(w(count))==0
		 w(count) = NaN;
		end
		HM(Pxy(count,1), Pxy(count,2)) = scale*abs(w(count));
		count = count + 1;
	end
end

h = fspecial('disk', 5);
HM2 = imfilter(HM, h);

figure('position',[0 0 500 500])
imagesc(IM2D)
colormap gray
colorbar
axis equal
axis off
set(gca,'color','w')
set(gcf,'color','w')

hold on
plot(Pxy(:,1),Pxy(:,2), '.b', 'markersize', 8)

figure('position',[0 0 500 500])
imagesc(HM2)
colormap jet
colorbar
axis equal
axis off
set(gca,'color','w')
set(gcf,'color','w')