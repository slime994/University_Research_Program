function [r, U, V, As, Bs, M, idm2D] = run_TSKCCA(ROI_3D)

%data_id = '160816b_t2000';
%DataFilePath = sprintf('/Users/tokunaga/KIT/motion/N2_data/%s', data_id);
%SaveFilePath = 'Users/tokunaga/KIT/motion/Hioki/MATLABPrograms/CreateMovies/160718b_t2000_normal';

Tmin = 2;%実際のフレームは初期値が104から
Tmax = 502;%実際のフレームは605まで
%Tmin = 104;
%Tmax = 604;
%Tmax = 1100+1;
thresh = 25;
width = 1;
sigx = 9;
sigy = 9;

%make_movie_data_Normal('160718b_t2000.avi', DataFilePath, Tmax); close(gcf)
%idm2D = Createidm2D(sprintf('%s/image', DataFilePath), sprintf('%s/image', DataFilePath), thresh, '160718b_t2000',Tmin, Tmax)
%[OpticalFlowU, OpticalFlowV] = createOpticalFlow(SaveFilePath, SaveFilePath, data_id, idm2D, Tmin, Tmax)

ROI_3D = ROI_3D(:,:,Tmin:Tmax);
%ROI_3D = addnoise_ROI_3D(ROI_3D, 200);%画像にノイズを付与する場合

IM2D = squeeze(ROI_3D(:,:,500));
[idm2D, idm] = Createidm2D(IM2D, width);
%y = make_step(ROI_3D, Tmin); %刺激時間が200のとき
y = make_step2(ROI_3D, Tmin); %刺激時間が400のとき

[Its Pxy] = extract_Its(ROI_3D, 1);
X = Its(idm, :);

save('X','X') %変数保存
[P N] = size(X);
Y = make_Y(y, X);

Kx = CreateYKernel(X, sigx);

Ky = CreateYKernel(Y, sigy);

%unique(isnan(Kx))
%unique(isnan(Ky))

param.No_Prj = 1;
param.No_Cmb = 1;
param.c1 = 10;
param.c2 = 5; % Hyper parameter for L1 regularization
param.c3 = 3; % Hyper parameter for fused lasso regularization
param.kappa = 0.02;
%[gr,Ds] = construct_Ni_TSKCCA(idm2D,length(idm2D), width);
%M = Fnorm(Ky, Kx(1:Tmax-Tmin+1, 1:Tmax-Tmin+1,:));
%M = Fnorm(Ky, Kx);

[r, U, V, As, Bs, M] = TSKCCA(1, idm2D, length(idm2D), Ky, Kx, param, width);
viz_U(IM2D, V, idm2D);