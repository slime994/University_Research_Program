function [idm2D idm] = Createidm2D(IM2D, width)


Threshold = 0;
[mrow mcol] = size(IM2D);
map = zeros(mrow, mcol);


%�i�q�_�쐬(8pixel��)
 for i = width:width:size(IM2D,1)
     for j =width:width:size(IM2D,2)
         map(i,j)=1;
     end
 end
 %�w�i�폜 
 for i =1: size(IM2D,1)
     for j =1: size(IM2D,2)
         if IM2D(i,j) <= Threshold
             IM2D(i,j) =0;
         end
    end
 end

%idm2D�쐬
idm2D = zeros(1000,2);
k=1;
count = 1;
for i =1: size(IM2D,1)
    for j =1: size(IM2D,2)
        if (map(i,j)==1) && (IM2D(i,j)~=0)
            idm2D(k,1)=j;
            idm2D(k,2)=i;
            idm(k) = count;
            k=k+1;
        end
        count = count + 1;
    end
end

idm2D(find(idm2D(:,1)<=0),:) = [];

end

