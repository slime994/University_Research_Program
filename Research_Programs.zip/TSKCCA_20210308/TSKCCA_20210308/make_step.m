function y = make_step(X, Tmin)

[mrow mcol T] = size(X);
y = zeros(T,1);
y(Tmin+100:Tmin+100+200)=1;


