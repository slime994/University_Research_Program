function unitstep = step()
%UNTITLED この関数の概要をここに記述
%   詳細説明をここに記述
t = (21:1:1200)';

a = ge(t,200);
b = le(t,400);
c = ge(t,800);
d = le(t,1000);

A = and(a,b);
B = and(c,d);
unitstep = or(A,B);

plot(t,unitstep)
ylim([-0.5 2])
xlabel('時刻(フレーム)')
ylabel('出力値')
end

