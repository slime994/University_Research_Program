function AllKernel = CreateYKernel(X,sgm)
%input X:Dataset[PxN]

[p,N] = size(X);
% Computation of the Kernel values K(xi,xj)
ret = zeros(N,N);
subKernel = zeros(N,N);
AllKernel = zeros(N,N,p);



%sgm = 1;	% kernel width


%createAllKernel
for Mx =1:p

    %createSubKernel
    for i = 1 : N
        %ret(:,i)= Kernel(X',X(:,i)',Mx);
        ret(:,i)= Kernel(X',X(Mx,:),i);
    end
    
    %prepalation
    M1 = mean(ret,1);
    M2 = mean(ret,2);
    M3 = 0;
    
    for a=1:N
        for b =1:N
            M3 = M3 + ret(a,b);
        end
    end
%     
%     a = [1:N];
%     b = [1:N];
%             
%     M3 = M3 + ret(a,b);
%     
%     M1_2d=zeros(N,N);
%     M2_2d=zeros(N,N);

%     for z = 1:N
% 
%         M1_2d(:,z)=M1(z);
%         M2_2d(z,:)=M2(z);
%         
%     end
    for n=1:N
        for k=1:N
            subKernel(n,k) =ret(n,k) -M1(k) -M2(n) + (1/N^2)*M3;
        end
    end
%     n = [1:N];
%     k = [1:N];
%             
%     subKernel(n,k) =ret(n,k) -M1_2d(n,k) -M2_2d(n,k) + (1/N^2)*M3;
    
    %disp(Mx)

    AllKernel(:,:,Mx) = subKernel;
    %AllKernel(:,:,Mx) = ret;
end








function k = Kernel(u,v,i)
[r1 c1] = size(u);
[r2 c2] = size(v);
k = zeros(r1,1);

for j = 1 : r1
%    k(j) = exp(-(u(j,:)-v)*(u(j,:)-v)'/(2*sgm^2));
     k(j) = exp( -(v(j)-v(i))^2 /(2*sgm^2));

end

end


end
