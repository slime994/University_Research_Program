function y = make_step2(X, Tmin)

[mrow mcol T] = size(X);
y = zeros(T,1);
y(Tmin+296:Tmin+296+200)=1;


