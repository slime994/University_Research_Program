function sparse_CCA(X, Y)

%if length(X)~=length(Y)
%    disp('### Error :: data size is not consistent ###')
%    break;end
%end

[T P] = size(X);

if T < P
    X = X';
    [T P] = size(X);
end

[T Q] = size(Y);

if T < Q
    Y = Y';
    [T Q] = size(Y);
end


A = zeros(P,1);
B = zeros(Q,1);

whos A X Y B

cvx_begin
    variable A(P, 1) 
    variable B(Q, 1)
    maximize(A'*X'*Y*B)
cvx_end