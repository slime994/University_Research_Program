function Y = make_Y(y, X)

[mrow mcol] = size(X);

%Y = zeros(round(mrow/2), mcol);
Y = zeros(40, mcol);
rng('default') 
%for id_row = 1:round(mrow/2)
for id_row = 1:40
	Y(id_row, :) = y + 0.1*randn(length(y), 1);
end
