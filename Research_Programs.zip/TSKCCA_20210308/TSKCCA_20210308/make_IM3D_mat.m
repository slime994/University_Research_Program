function IM4D = make_IM3D_mat(DirName)


FileList = dir(DirName);
N = length(FileList);
count = 1;

for i=3:N-1
	FILENAME = FileList(i).name;
	load(sprintf('/Users/tokunaga/KIT/MotionSeg/%s/%s', DirName, FILENAME));
	if count == 1
		[mrow mcol d] = size(IM);
		IM4D = zeros(mrow, mcol, N);
	end
	
	if d > 1
		IM = rgb2gray(IM);
	end
	
	IM4D(:,:,count) = IM;
	count = count + 1;
end

