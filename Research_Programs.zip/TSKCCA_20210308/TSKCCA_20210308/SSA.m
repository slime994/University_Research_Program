function [ssa_sig,Sigma]=SSA(x,L);

%-------------------------------------------------------------------
%This function is a Basic SSA (Singlar Spectrum Analysis) algorithm  
%written by Terumasa Tokunaga. The algorithm consists of three steps,
%embedding,singular value decomposition and diagonal averaging.     
%Redistribution is prohibited. 
%                            2008/10/25 ver.1 
%-------------------------------------------------------------------
%
%x:observed data
%L:the dimension of embedding
%ssa_sig:SSA basis functions
%Lamda:standard devision for each eigen vector 
%
%                  Note that L must be smallter than N
%

N=length(x);
K=N-L+1; %K:window width
HH=[];

% Default values
firstEig=1;%The first component used in STEP3
lastEig=10;%The last component used in STEP3


% Default values for optional parameters
display_eigenvalues = 1;% 1-->plot data
display_basis_function = 0;
display_trend = 1;



%-----------------------------------------------------------
% Step1:embedding time serius data to produce a Hankel matrix
%-----------------------------------------------------------
for i=1:L
   
    x_lag=x(i:K+i-1);%x_lag:L-dimensional lag vector
    HH=[HH,x_lag]; %HH:L-trajectory matrix or K*L Hankel matrix   
    clear x_lag;
end


%-----------------------------------------------------------
% Step2:singular value decomposition (SVD) 
% time space-->frequency space
%-----------------------------------------------------------
[U,S,V] = svd(HH);%svd is a MATLAB function
Sigma=diag(S.^0.5);%Sigma:standard devision for each eigen vector

if display_eigenvalues==1;% plot square root of lamda i.e. eigenvalues
 figure;
 bar(Sigma(1:L));
 set(gca,'xlim',[0 L+1])
 title('eigenvalues','fontsize',15)
end
 


%-----------------------------------------------------------
% Step3:diagonal averaging  %frequency space--> time space
%----------------------------------------------------------- 
 
V2=V';
Xt=[];

for i=firstEig:lastEig;    
    Xi=S(i,i)*U(:,i)*V2(i,:);
     Xi=Xi';
    Xi_ave=X_ave(Xi,L,K);%The original function for diagonal averaging
    Xt=[Xt;Xi_ave];
    clear Xi_ave Xi    
end;

ssa_sig=Xt;



%---------------------------------------------------------------
%                    plot optional figures
%---------------------------------------------------------------

if display_trend==1;
   figure
   plot(x,'linewidth',1.2)
   hold on
   plot(ssa_sig(1,:),'r','linewidth',1.5)
   legend('raw data','1st comp.')   
end

if display_basis_function==1;   
subplot_ICs(ssa_sig,'SSA basis functions')
end

