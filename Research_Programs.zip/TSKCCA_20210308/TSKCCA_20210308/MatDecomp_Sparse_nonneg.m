function [U,D,V,E]=MatDecomp_Sparse_nonneg(cvxFlag,idm2D,FlowNum,X,params,k,width)
% this function returns non-negative singular matrix decomposition 
% with L1 reg.
%
% [U,D,V,E]=MatDecomp_Sparse_nonneg(X,K)
%
% inputs:
% X :n*p matrix
% k :specified #components
% c1,c2:upper bound of L1 norm
%
% outputs:
% U :n*k matrix
% D :k*k matrix whose diagnal elements are singular values
% V :p*k matrix



[n,p]=size(X);


if ~exist('k','var') 
    k=min(n,p);
end

U=zeros(n,k);
D=zeros(k,k);
V=zeros(p,k);

for i=1:k
  disp(i)
   [X,d,u,v] = SparseSingleMD(cvxFlag,idm2D,FlowNum,X,params,width); 
   D(i,i)=d;
   U(:,i)=u;
   V(:,i)=v;
end
E=X;
[d,id]=sort(diag(D),'descend');
D=diag(d);
U=U(:,id);
V=V(:,id);
end


function  [X,d,u,v]=SparseSingleMD(cvxFlag, idm2D, FlowNum, X, params, width)
% this function returns rank-1 non-negative singular value decomposition 
% with L1 reg.
%
% [X,d,u,v]=SparseSinglMD(X)
%
% X:input
% c1,c2:upper bound of L1 norm
%
% d:first singular value
% u,v:first singular vectors

c1 = params.c1;
c2 = params.c2;
p = length(idm2D);
nn=1;
tol=1e-4;
MaxIt=10000;

%initilize
[~,~,v_old]=svds(X,1);
v_old=abs(v_old/norm(v_old,2));
u_old=X*v_old/norm(X*v_old,2);
p = size(v_old,1);

for i=1:MaxIt
    %update u
    argu=X*v_old;
    lmbd1=BinarySearch(argu,c1,nn);
    su=l1_softth(argu,lmbd1);
    su(su<0)=0;
    u=su/norm(su,2);
  
    if cvxFlag == 0
          %update v
          argv=X'*u;
          lmbd2=BinarySearch(argv,c2,nn);
          sv=l1_softth(argv,lmbd2);
          sv(sv<0)=0;
          v=sv/norm(sv,2);     
    end
    
    
     if cvxFlag == 1
             %cvx param 
             %ramuda1 = 0.01;  
             %ramuda2 = 0.05; 
             %construct_Ni
             gr = construct_Ni_TSKCCA(idm2D, length(idm2D), width);
 
                cvx_begin quiet
                variable v(p) 
                    minimize((X'*u-v)'*(X'*u-v))
                    subject to
                      norm(v,1) <= params.c2; 
                      norm(v,2) <= 1
                      sum( abs( v(gr(:,1))- v(gr(:,2)) ) ) <= params.c3
                cvx_end 
     
     end
    
    
    if norm(u_old-u,2)<tol && norm(v_old-v,2)<tol
        break;
    end
    u_old=u;
    v_old=v;  
end

d=u'*X*v;
X=X-d*u*v';
end
