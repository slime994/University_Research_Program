function [Its Pxy] = extract_Its(IM3D, width)

[mrow, mcol, T] = size(IM3D);
count = 1;

for id_row = 1:width:mrow
	for id_col = 1:width:mcol
		It = IM3D(id_row, id_col, :);
		It = It - mean(It);
		scale = max(It(:)) - min(It(:));
        
        if scale == 0
        scale = 1;
        end
        
		It = 100*It/scale;
		It(isnan(It))=0;
		Its(count, :) = It;
		Pxy(count, :) = [id_row, id_col];
		count = count + 1;
	end
end

%12～14行目のif文は付け加え