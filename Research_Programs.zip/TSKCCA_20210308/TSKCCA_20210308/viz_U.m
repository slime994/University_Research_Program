function Pxy = viz_U(IM, U, idm2D)

U = U - min(U(:));
U = U/norm(U);
[P d] = size(idm2D);
thresh = max(U(:))/2;

figure
imagesc(IM) %IMの画像出力
colormap gray
hold on
maxU = max(U(:,1));
%scale = 1000/maxU;
scale = 1e2; %1e2 = 1*10^2
Pxy = [];
for i=1:P
    Ui = U(i);
    %disp(Ui)
    if Ui > thresh
        plot(idm2D(i,1), idm2D(i,2), 'm.', 'markersize', scale*Ui)
        Pxy = [Pxy ; idm2D(i,:)];
        %disp(scale*Ui)
    else
         plot(idm2D(i,1), idm2D(i,2),'m.', 'markersize', 0.01)
    end
    
end
        [k,av] = convhull(Pxy);
        plot(Pxy(k,1),Pxy(k,2))
end