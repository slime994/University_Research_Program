function trans_superPx2D(DirName, DirName2, Nseg, comp)

FileList = dir(DirName);
N = length(FileList);
count = 1;

figure('position',[0 0 300 300])

for i = 4:N
	FILENAME = FileList(i).name;
	if length(FILENAME) > 10
		IM = imread(sprintf('%s/%s', DirName, FILENAME));
		[BW, L, N] = superPx2D(IM, Nseg, comp);
		outputImage = zeros(size(IM),'like', IM);
		idx = label2idx(L);
		for labelVal = 1:N
			grayIdx = idx{labelVal};
			outputImage(grayIdx) = mean(IM(grayIdx));
		end    

		if count == 1
			[mrow mcol] = size(IM);
		end
		
		%imshow(outputImage,'InitialMagnification', 650)
		imshow(imoverlay(outputImage, BW,'white'),'InitialMagnification', 650)
		count = count + 1;
	end
	set(gca,'Position',get(gca,'OuterPosition'));
	drawnow
	set(gcf, 'PaperPositionMode', 'manual');
	set(gcf, 'PaperUnits', 'inches');
	set(gcf, 'PaperPosition', [1 1 2 2]);
	print(sprintf('%s/%s', DirName2, FILENAME), '-dpng')
end
