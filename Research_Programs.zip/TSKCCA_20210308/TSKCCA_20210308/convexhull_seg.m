function convexhull_seg(Pxy, IM)


x = Pxy(:,1);
y = Pxy(:,2);
K = convhull(y, x);

figure('position',[0 0 300 300])
imagesc(IM)
colormap gray
hold on
plot(x, y,'c.','markersize', 15)
xlabel('Longitude')
ylabel('Latitude')
hold on
plot(x(K), y(K), 'r', 'linewidth', 2)
axis equal
axis off
set(gcf,'color','k')