function plot_data(X)

[N d] = size(X);

if N < d
    X = X';
    [N d] = size(X);
end


figure
hold on
for i=1:d
    Xi = X(:, i)/std(X(:,i));
    plot(Xi)
end