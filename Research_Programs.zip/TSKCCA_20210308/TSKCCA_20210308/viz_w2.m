function viz_w2(w, Pxy, IM2D, scale)

w = w/sum(w);

figure
imagesc(IM2D)
hold on
count =  1;
N = sqrt(length(Pxy));
for id_row = 1:N
	for id_col = 1:N
		HM(id_row,id_col) = w(count);
		if abs(w(count))==0
		 w(count) = NaN;
		end
		scatter(Pxy(count,1),Pxy(count,2),scale*abs(w(count)))
		count = count + 1;
	end
end

